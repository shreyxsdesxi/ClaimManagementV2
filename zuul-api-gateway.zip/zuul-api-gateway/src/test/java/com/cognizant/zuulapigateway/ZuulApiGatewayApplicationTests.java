package com.cognizant.zuulapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
